

import { useMemo } from "react";
import { useDragDropManager } from "../useDragDropManager";
import {DragSourceMonitorImpl} from '../../internals';
function useDragSourceMonitor() {
    const manager = useDragDropManager();
    return useMemo(() => new DragSourceMonitorImpl(manager), [manager])
}
export default useDragSourceMonitor;





class DragSourceMonitorImpl {
    internalMonitor
    constructor(manager) {
        // 某个源的监听器 会有一个内部指针指向全局监听器
        this.internalMonitor = manager.getGlobalMonitor()
    }
}
export default DragSourceMonitorImpl;
