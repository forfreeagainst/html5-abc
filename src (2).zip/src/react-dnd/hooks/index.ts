import useDragSourceMonitor from './useDragSourceMonitor';

function useDrag(spec) {
    const monitor = useDragSourceMonitor();
    return [{}, () => {}]
}

export default useDrag;

/**
 * monitor有两个级别
 * 全局monitor 只有一个
 * 拖动元或放置目标的monitro ,每个源或目标都有一份。
 * 
 * 
 */