import { useState } from "react"
import Card from './Card'
function CardContainer() {
  const [cards, setCards] = useState([
    {id:'1', text:"durant"},
    {id: '2', text: 'curry'},
    {id: '3', text: 'james'}
  ])
  const moveCard = (dragIndex:number, hoverIndex:number) => {
    console.log('??')
    const dragCard = cards[dragIndex];
    let cloneCards = [...cards];
    cloneCards.splice(dragIndex, 1);
    cloneCards.splice(hoverIndex, 0, dragCard);
    setCards(cloneCards)
  }
  return (
    <>
      <div>{
        cards.map((item, index) => {
          return <Card text={item.text} key={item.id} moveCard={moveCard} id={item.id} index={index}></Card>
        })
        }</div>
    </>
  )
}

export default CardContainer
