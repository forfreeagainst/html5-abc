import { createStore } from "redux";
import reducer from './reducers'
import DragDropManagerImpl
import DragDropMonitorImpl from "./classes/DragDropMonitorImpl";

/**
 * 管理器相当于总经理，管理着所有的东西
 * 
 */

function createDragDropManager(backendFactory) {
    const store = createStore(reducer);
    const globalMonitor = new DragDropMonitorImpl(store);
    const manager = new DragDropManagerImpl(store, globalMonitor);
    const backend = backendFactory(manager);
    manager.receiveBackend(backend);
    return manager;
}