import HTML5BackendImpl from './HTML5BackendImpl';

export function HTML5Backend() {
    return new HTML5BackendImpl();
}