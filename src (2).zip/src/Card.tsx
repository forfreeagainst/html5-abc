import { useDrag, useDrop } from "react-dnd"
import {CARD} from './ItemTypes';
import { useRef } from "react";
const CardStyle = {
    padding: '5px',
    margin: '5px',
    border: "solid 1px gray",
    cursor: 'move',
    width: '300px',
    minHeight: '60px',
    background: 'pink'
}
function Card({ id, text, index, moveCard }: any) {
    const ref = useRef(null);

    let [, drop] = useDrop({
        accept: CARD,
        collect: () => ({}),
        hover(item: any, monitor) {
            // 获取被拖动的卡片的索引 0
            const dragIndex = item.index;
            // 当前正在hover卡片的索引 1
            const hoverIndex = index;
            if (dragIndex === hoverIndex) {
                return;
            }

            const { top, bottom } = ref.current.getBoundingClientRect();
            const halfOfHoverHeight = (bottom - top) / 2;
            const { y } = monitor.getClientOffset(); // event.clientY
            const hoverClientY = y - top;
            if ((dragIndex < hoverIndex && hoverClientY > halfOfHoverHeight)
                || (dragIndex > hoverIndex && hoverClientY < halfOfHoverHeight)
            ) {
                moveCard(dragIndex, hoverIndex);
                item.index = hoverIndex;
            }
        }
    })

    let [{ isDragging }, drag] = useDrag({
        type: CARD,
        item: () => ({ id, index }),
        collect: (monitor) => ({
            isDragging: monitor.isDragging()
        })
    })
    const opacity = isDragging ? .1 : 1;
    drag(ref)
    drop(ref)
    return (
        <>
            <div ref={ref} style={{ ...CardStyle, opacity }}>{text}</div>
        </>
    )
}

export default Card
